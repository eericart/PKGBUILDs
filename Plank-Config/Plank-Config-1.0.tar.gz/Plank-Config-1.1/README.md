Plank-Config
============

A tool to configure Plank Dock.


### Introduction

This little tool allows anyone to change settings of Plank Dock. Based on [Switchboard Desktop Plug](https://launchpad.net/switchboard-plug-pantheon-shell) without Switboard. 

### Build dependencies

`gcc`

`gtk3-devel >= 3.10.0`

`vala >= 0.16.0`
### Install 
To build and install this program:

./autogen.sh
make
make install

### License: GPLv2
