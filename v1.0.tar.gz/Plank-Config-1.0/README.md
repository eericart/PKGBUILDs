Plank-Config
============

A tool to configure Plank Dock.

### Introduction

This little tool allows anyone to change settings of Plank Dock. Based on [Switchboard Desktop Plug](https://launchpad.net/switchboard-plug-pantheon-shell) without Switboard. 

### License: GPLv2
